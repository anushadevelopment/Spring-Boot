package com.cancodelah.customer.card.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerCardServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
